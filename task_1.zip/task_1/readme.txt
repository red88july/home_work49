1.mkdir projects
2.cd projects
3.mkdir my_project
4.cd my_project
5.mkdir directory1 directory2 directory3
6.cd directory1
7.mkdir subdirectory1
8.cd ..
9.cd directory2
10.echo "Hello from JS" > hello.txt
11.cd ..
12.cd directory3
12.mkdir subdirectory2 
